document.addEventListener('DOMContentLoaded', () => {
    const cells = document.querySelectorAll('.cell');
    const restartButton = document.getElementById('restart-button');
    const playerTurnElement = document.getElementById('player-turn');
    const scoreXElement = document.getElementById('score-x');
    const scoreOElement = document.getElementById('score-o');

    let currentPlayer = 'x';
    let board = Array(9).fill(null);
    let scoreX = 0;
    let scoreO = 0;

    function checkWinner() {
        const winningCombinations = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6]
        ];

        for (const combination of winningCombinations) {
            const [a, b, c] = combination;
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                highlightWinningCells([a, b, c]);
                return board[a];
            }
        }

        if (!board.includes(null)) {
            return 'draw';
        }

        return null;
    }

    function highlightWinningCells(indices) {
        indices.forEach(index => {
            cells[index].classList.add('winning');
        });
    }

    function handleClick(event) {
        const cell = event.target;
        const index = cell.getAttribute('data-index');

        if (board[index] || checkWinner()) {
            return;
        }

        board[index] = currentPlayer;
        cell.classList.add(currentPlayer);
        cell.textContent = currentPlayer.toUpperCase();

        const winner = checkWinner();

        if (winner) {
            setTimeout(() => {
                if (winner === 'draw') {
                    alert("It's a draw!");
                } else {
                    alert(`${winner.toUpperCase()} wins!`);
                    updateScore(winner);
                }
                restartGame();
            }, 1000);
        } else {
            currentPlayer = currentPlayer === 'x' ? 'o' : 'x';
            playerTurnElement.textContent = currentPlayer.toUpperCase();
        }
    }

    function updateScore(winner) {
        if (winner === 'x') {
            scoreX++;
            scoreXElement.textContent = `X: ${scoreX}`;
        } else if (winner === 'o') {
            scoreO++;
            scoreOElement.textContent = `O: ${scoreO}`;
        }
    }

    function restartGame() {
        board.fill(null);
        cells.forEach(cell => {
            cell.classList.remove('x', 'o', 'winning');
            cell.textContent = '';
        });
        currentPlayer = 'x';
        playerTurnElement.textContent = currentPlayer.toUpperCase();
    }

    cells.forEach(cell => cell.addEventListener('click', handleClick));
    restartButton.addEventListener('click', restartGame);
});
